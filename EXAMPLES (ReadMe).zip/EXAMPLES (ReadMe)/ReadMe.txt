Please check some .html files with examples (HTML, CSS, JS, JSON queries included). I have also pasted some links below.

Template Editor Tool
	http://www.apolosiskos.co.uk/HTML-CSS_EDITOR/%5bB-Dat001%5d/

Percentage_Share (X Dimensions) [HTML FILE ATTACHED TOO]
	http://www.apolosiskos.co.uk/SAMPLES/11/  

JSON to HTML Table 2
	http://www.apolosiskos.co.uk/DASHBOARD_EXAMPLES/widget.html  

JSON to HTML Table 3 and Extra
	http://www.apolosiskos.co.uk/BET/index.html 

Infobox (html loaded from dropbox link) [HTML FILE ATTACHED]
	INSTRUCTIONS: Change the JSON queries in the javascript to see the possible 			      scenarios (number of boxes shown)

Merge two datasets (Aggregation) using Python (Pandas)
	http://www.apolosiskos.co.uk/SAMPLES/10/

